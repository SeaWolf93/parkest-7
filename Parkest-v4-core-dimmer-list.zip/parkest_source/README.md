# Parkest

**Il tuo tempo, conta.**

Versione pre-lancio del prototipo Parkest.

## Funzioni incluse
- Supabase Auth con registrazione/login email+password, nome utente, sessione persistente e logout.
- Homepage personalizzata: “Benvenuto/a, Nome”.
- Mappa Leaflet/OpenStreetMap e GPS con fallback di test su Savona.
- Raggi 300 m, 500 m, 1 km, 2 km e 5 km.
- Sistema semaforico: verde = LIBERO, arancione = si libera tra X min, rosso = IN_ARRIVO, OCCUPATO = nascosto.
- Pre-segnalazione: Adesso, 5, 15, 20, 30, 45, +45 minuti.
- Countdown `X min` direttamente sul marker arancione; pulsazione sotto i 10 minuti.
- Supabase Realtime.
- Notifiche browser per nuovi posti liberi e soglia 10 minuti, senza duplicati.
- Blocco del proprio parcheggio e protezione client-side contro doppio VAI simultaneo.

## Prima di usare questa versione
1. In Supabase Authentication abilita Email/Password.
2. Configura Site URL / Redirect URL con il dominio Netlify.
3. Esegui `supabase_migration.sql` in Supabase > SQL Editor.
4. Pubblica questi file su Netlify.
5. Apri Parkest, inserisci Supabase URL + publishable/anon key nelle impostazioni e crea due account di prova.

## Nota notifiche
Le notifiche implementate qui usano la Notification API del browser e Supabase Realtime. Sono adatte al prototipo e ai test con il sito aperto/attivo. Notifiche push affidabili a browser/app completamente chiusi richiederanno una fase successiva con Web Push/Service Worker e un backend di invio push.


## v3 – indirizzi leggibili
La UI usa reverse geocoding OpenStreetMap/Nominatim per mostrare via/piazza e località al posto delle coordinate GPS. Le coordinate restano interne per distanza e navigazione. Se il servizio non risponde, Parkest mostra “Posizione sulla mappa”.
