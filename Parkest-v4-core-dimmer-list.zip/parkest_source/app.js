// Parkest — client-side logic. Supabase JS v2 + Realtime + Leaflet/OpenStreetMap.

const TEST_LAT = 44.3075;
const TEST_LNG = 8.4810;
const HOME_RADIUS = 500;

const state = {
  supabase: null,
  user: null,
  authMode: 'login',
  leaveMinutes: 0,
  notificationMemory: new Set(JSON.parse(localStorage.getItem('parkest_notified') || '[]')),
  lascio: { lat:null, lng:null, isTest:false, map:null, marker:null },
  cerco: { lat:null, lng:null, isTest:false, radius:500, spots:[], channel:null, map:null, markersLayer:null, userMarker:null, radiusCircle:null },
  arrivalWatch: { watchId:null, spotId:null, nearSince:null, prompted:false },
  geocodeCache: new Map(),
  geocodePending: new Map(),
};

const $ = id => document.getElementById(id);

// ---------- Light / dark dimmer ----------
function applyTheme(theme){
  const dark=theme==='dark';
  document.body.classList.toggle('dark',dark);
  const b=$('btn-theme'); if(b){b.textContent=dark?'☀️':'🌙'; b.setAttribute('aria-label',dark?'Modalità giorno':'Modalità notte');}
}
const savedTheme=localStorage.getItem('parkest_theme') || 'light';
applyTheme(savedTheme);
$('btn-theme')?.addEventListener('click',()=>{const next=document.body.classList.contains('dark')?'light':'dark';localStorage.setItem('parkest_theme',next);applyTheme(next);});

// ---------- Views ----------
function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  $(id).classList.add('active');
}

function showAppForSession() {
  if (!state.supabase) { showView('view-auth'); return; }
  if (!state.user) { showView('view-auth'); return; }
  updateWelcome();
  $('btn-logout').classList.remove('hidden');
  showView('view-home');
  refreshHomeSummary();
}

$('btn-mode-lascio').addEventListener('click', () => { if (!requireAuth()) return; showView('view-lascio'); startLascio(); });
$('btn-mode-cerco').addEventListener('click', () => { if (!requireAuth()) return; showView('view-cerco'); startCerco(); });
document.querySelectorAll('[data-back]').forEach(btn => btn.addEventListener('click', () => { stopCercoChannel(); showView('view-home'); refreshHomeSummary(); }));

// ---------- Toast ----------
function showToast(message, ms=4000) {
  const el=document.createElement('div'); el.className='toast'; el.textContent=message; $('toast-container').appendChild(el); setTimeout(()=>el.remove(),ms);
}

// ---------- Supabase connection + Auth ----------
function loadSavedConnection() {
  const url=localStorage.getItem('parkest_supabase_url');
  const key=localStorage.getItem('parkest_supabase_key');
  if (url && key) connectSupabase(url,key,false);
  else showView('view-auth');
}

async function connectSupabase(url,key,persist=true) {
  try {
    state.supabase=window.supabase.createClient(url,key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    if (persist) { localStorage.setItem('parkest_supabase_url',url); localStorage.setItem('parkest_supabase_key',key); }
    $('connection-status').textContent='Collegato a Parkest ✓'; $('connection-status').style.color='var(--green-dark)';
    $('auth-connection-hint').textContent='Parkest è collegato. Puoi accedere o registrarti.';
    wireAuthListener();
    const {data}=await state.supabase.auth.getSession();
    state.user=data.session?.user || null;
    showAppForSession();
    return true;
  } catch(e) {
    $('settings-feedback').textContent='Errore di connessione: '+(e.message||'credenziali non valide.');
    return false;
  }
}

let authListenerWired=false;
function wireAuthListener() {
  if (authListenerWired || !state.supabase) return;
  authListenerWired=true;
  state.supabase.auth.onAuthStateChange((_event,session)=>{
    state.user=session?.user || null;
    if (state.user) showAppForSession();
    else { $('btn-logout').classList.add('hidden'); showView('view-auth'); }
  });
}

function requireSupabase() {
  if (!state.supabase) { showToast('Collega prima Parkest a Supabase dalle impostazioni ⚙︎.'); $('settings-overlay').classList.remove('hidden'); return false; }
  return true;
}
function requireAuth() { if (!requireSupabase()) return false; if (!state.user) { showToast('Accedi prima al tuo account Parkest.'); showView('view-auth'); return false; } return true; }

function updateWelcome() {
  const name=state.user?.user_metadata?.name?.trim() || state.user?.email?.split('@')[0] || '';
  $('welcome-name').textContent=`Benvenuto/a${name ? ', '+name : ''} 👋`;
}

$('tab-login').addEventListener('click',()=>setAuthMode('login'));
$('tab-register').addEventListener('click',()=>setAuthMode('register'));
function setAuthMode(mode) {
  state.authMode=mode;
  $('tab-login').classList.toggle('active',mode==='login'); $('tab-register').classList.toggle('active',mode==='register');
  $('register-name-wrap').classList.toggle('hidden',mode!=='register'); $('register-confirm-wrap').classList.toggle('hidden',mode!=='register');
  $('btn-auth-submit').textContent=mode==='login'?'ACCEDI':'CREA ACCOUNT'; $('auth-feedback').textContent='';
}

$('btn-auth-submit').addEventListener('click',async()=>{
  if (!requireSupabase()) return;
  const email=$('auth-email').value.trim(); const password=$('auth-password').value; const name=$('auth-name').value.trim();
  if (!email || !password) { $('auth-feedback').textContent='Inserisci email e password.'; return; }
  $('btn-auth-submit').disabled=true; $('auth-feedback').textContent='Attendi…';
  try {
    if (state.authMode==='register') {
      if (!name) throw new Error('Inserisci il tuo nome.');
      if (password.length<6) throw new Error('La password deve avere almeno 6 caratteri.');
      if (password!==$('auth-password-confirm').value) throw new Error('Le password non coincidono.');
      const {data,error}=await state.supabase.auth.signUp({email,password,options:{data:{name}}});
      if (error) throw error;
      if (!data.session) $('auth-feedback').textContent='Account creato. Controlla la tua email per confermarlo.';
      else $('auth-feedback').textContent='Account creato!';
    } else {
      const {data,error}=await state.supabase.auth.signInWithPassword({email,password}); if (error) throw error;
      state.user=data.user || data.session?.user || null;
      $('auth-feedback').textContent='Accesso effettuato.';
      if(state.user) showAppForSession();
    }
  } catch(e) { $('auth-feedback').textContent=e.message||'Operazione non riuscita.'; }
  finally { $('btn-auth-submit').disabled=false; }
});

$('btn-logout').addEventListener('click',async()=>{ if (!state.supabase) return; await state.supabase.auth.signOut(); $('settings-overlay').classList.add('hidden'); showToast('Sei uscito da Parkest.'); });

$('btn-settings').addEventListener('click',()=>{ $('input-url').value=localStorage.getItem('parkest_supabase_url')||''; $('input-key').value=localStorage.getItem('parkest_supabase_key')||''; $('settings-feedback').textContent=''; $('btn-logout').classList.toggle('hidden',!state.user); $('settings-overlay').classList.remove('hidden'); });
$('btn-close-settings').addEventListener('click',()=>$('settings-overlay').classList.add('hidden'));
$('btn-connect').addEventListener('click',async()=>{ const url=$('input-url').value.trim(),key=$('input-key').value.trim(); if(!url||!key){$('settings-feedback').textContent='Inserisci URL e chiave.';return;} const ok=await connectSupabase(url,key,true); if(ok){$('settings-feedback').textContent='Connesso con successo!';setTimeout(()=>$('settings-overlay').classList.add('hidden'),700);} });

// ---------- Geolocation ----------
function geolocate(onPosition,onFallback) {
  if(!navigator.geolocation){onFallback();return;}
  navigator.geolocation.getCurrentPosition(p=>onPosition(p.coords.latitude,p.coords.longitude),()=>onFallback(),{enableHighAccuracy:true,timeout:8000,maximumAge:15000});
}


// ---------- Reverse geocoding (coordinates -> street / square) ----------
function geocodeKey(lat,lng){return `${Number(lat).toFixed(5)},${Number(lng).toFixed(5)}`;}
function formatAddressFromNominatim(data){
  const a=data?.address||{};
  const road=a.road||a.pedestrian||a.footway||a.cycleway||a.residential||a.path||a.square||a.place||a.neighbourhood||a.suburb||'';
  const house=a.house_number||'';
  const city=a.city||a.town||a.village||a.municipality||a.county||'';
  const primary=[road,house].filter(Boolean).join(' ');
  if(primary&&city) return `${primary}, ${city}`;
  if(primary) return primary;
  if(a.neighbourhood&&city) return `${a.neighbourhood}, ${city}`;
  if(city) return city;
  return data?.display_name?.split(',').slice(0,2).join(',').trim()||'Posizione sulla mappa';
}
async function reverseGeocode(lat,lng){
  const key=geocodeKey(lat,lng);
  if(state.geocodeCache.has(key)) return state.geocodeCache.get(key);
  if(state.geocodePending.has(key)) return state.geocodePending.get(key);
  const req=(async()=>{
    try{
      const url=`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lng)}&zoom=18&addressdetails=1&accept-language=it`;
      const r=await fetch(url,{headers:{'Accept':'application/json'}});
      if(!r.ok) throw new Error('reverse geocoding unavailable');
      const data=await r.json();
      const label=formatAddressFromNominatim(data);
      state.geocodeCache.set(key,label);
      return label;
    }catch(_e){
      const fallback='Posizione sulla mappa';
      state.geocodeCache.set(key,fallback);
      return fallback;
    }finally{state.geocodePending.delete(key);}
  })();
  state.geocodePending.set(key,req);
  return req;
}
function cachedAddress(lat,lng){return state.geocodeCache.get(geocodeKey(lat,lng))||'Ricerca indirizzo…';}
async function hydrateAddress(lat,lng,onReady){const label=await reverseGeocode(lat,lng);if(onReady)onReady(label);return label;}

// ---------- Map helpers ----------
function pinIcon(colorClass){return L.divIcon({className:'',html:`<div class="map-pin ${colorClass}"></div>`,iconSize:[28,28],iconAnchor:[14,28],popupAnchor:[0,-28]});}
function timedPinIcon(minutes){const soon=minutes<=10?' soon':'';return L.divIcon({className:'',html:`<div class="timed-pin${soon}">${minutes} min</div>`,iconSize:[62,38],iconAnchor:[8,34],popupAnchor:[20,-32]});}
function userDotIcon(){return L.divIcon({className:'',html:'<div class="user-dot"></div>',iconSize:[16,16],iconAnchor:[8,8]});}
function addOsmTileLayer(map){L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);}
function isScheduled(spot){return spot.status==='LIBERO' && spot.available_at && new Date(spot.available_at).getTime()>Date.now();}
function minutesRemaining(spot){if(!spot.available_at)return 0;return Math.max(0,Math.ceil((new Date(spot.available_at).getTime()-Date.now())/60000));}
function visualStatus(spot){if(spot.status==='IN_ARRIVO')return 'IN_ARRIVO'; if(isScheduled(spot))return 'SCHEDULED'; return spot.status;}

// ---------- LASCIO ----------
function initLascioMap(lat,lng){
  if(!state.lascio.map){state.lascio.map=L.map('lascio-map').setView([lat,lng],16);addOsmTileLayer(state.lascio.map);state.lascio.marker=L.marker([lat,lng],{icon:pinIcon('pin-green'),draggable:true}).addTo(state.lascio.map);state.lascio.marker.on('dragend',()=>{const p=state.lascio.marker.getLatLng();state.lascio.lat=p.lat;state.lascio.lng=p.lng;updateLascioCoords();});state.lascio.map.on('click',e=>{state.lascio.marker.setLatLng(e.latlng);state.lascio.lat=e.latlng.lat;state.lascio.lng=e.latlng.lng;updateLascioCoords();});}
  else{state.lascio.map.setView([lat,lng],16);state.lascio.marker.setLatLng([lat,lng]);}
  setTimeout(()=>state.lascio.map.invalidateSize(),0);
}
function startLascio(){const status=$('lascio-status'),badge=$('lascio-test-badge'),btn=$('btn-confirm-lascio');$('lascio-result').textContent='';btn.disabled=true;badge.classList.add('hidden');status.textContent='Rilevamento posizione GPS…';setLeaveMinutes(0);geolocate((lat,lng)=>{Object.assign(state.lascio,{lat,lng,isTest:false});status.textContent='Posizione rilevata tramite GPS.';btn.disabled=false;updateLascioCoords();initLascioMap(lat,lng);},()=>{Object.assign(state.lascio,{lat:TEST_LAT,lng:TEST_LNG,isTest:true});status.textContent='GPS non disponibile.';badge.classList.remove('hidden');btn.disabled=false;updateLascioCoords();initLascioMap(TEST_LAT,TEST_LNG);});}
function updateLascioCoords(){if(state.lascio.lat==null)return;const lat=state.lascio.lat,lng=state.lascio.lng;$('lascio-address').textContent='Ricerca indirizzo…';hydrateAddress(lat,lng,label=>{if(state.lascio.lat===lat&&state.lascio.lng===lng)$('lascio-address').textContent=label;});}
function setLeaveMinutes(value){state.leaveMinutes=value;document.querySelectorAll('#leave-time-chips .time-chip').forEach(c=>c.classList.toggle('active',c.dataset.minutes===String(value)));$('custom-minutes-wrap').classList.toggle('hidden',value!=='custom');}
document.querySelectorAll('#leave-time-chips .time-chip').forEach(chip=>chip.addEventListener('click',()=>setLeaveMinutes(chip.dataset.minutes==='custom'?'custom':parseInt(chip.dataset.minutes,10))));

$('btn-confirm-lascio').addEventListener('click',async()=>{
  if(!requireAuth())return; const btn=$('btn-confirm-lascio'),result=$('lascio-result'); btn.disabled=true;result.textContent='Pubblicazione in corso…';
  let minutes=state.leaveMinutes==='custom'?parseInt($('custom-minutes').value,10):state.leaveMinutes;
  if(!Number.isFinite(minutes)||minutes<0||(state.leaveMinutes==='custom'&&minutes<=45)){result.textContent='Inserisci un tempo superiore a 45 minuti.';btn.disabled=false;return;}
  const availableAt=new Date(Date.now()+minutes*60000).toISOString();
  const {error}=await state.supabase.from('parking_spots').insert({lat:state.lascio.lat,lng:state.lascio.lng,status:'LIBERO',released_by:state.user.id,claimed_by:null,available_at:availableAt});
  if(error){result.textContent='Errore: '+error.message;btn.disabled=false;return;}
  result.textContent=minutes===0?'Parcheggio pubblicato come libero!':`Parcheggio segnalato: disponibile tra ${minutes} min.`;showToast(minutes===0?'Parcheggio libero pubblicato.':`Pre-segnalazione pubblicata: ${minutes} min.`);setTimeout(()=>{showView('view-home');refreshHomeSummary();},1200);
});

// ---------- Navigation + smart arrival ----------
function navigateToSpot(spot){
  const dest=`${spot.lat},${spot.lng}`;
  const isApple=/iPhone|iPad|iPod|Macintosh/i.test(navigator.userAgent);
  const url=isApple?`https://maps.apple.com/?daddr=${encodeURIComponent(dest)}&dirflg=d`:`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}&travelmode=driving`;
  window.open(url,'_blank','noopener');
}
function stopArrivalWatch(){
  if(state.arrivalWatch.watchId!=null && navigator.geolocation) navigator.geolocation.clearWatch(state.arrivalWatch.watchId);
  state.arrivalWatch={watchId:null,spotId:null,nearSince:null,prompted:false};
}
function startArrivalWatch(spot){
  stopArrivalWatch();
  if(!navigator.geolocation || state.cerco.isTest) return;
  state.arrivalWatch.spotId=spot.id;
  state.arrivalWatch.watchId=navigator.geolocation.watchPosition(pos=>{
    const d=haversineMeters(pos.coords.latitude,pos.coords.longitude,spot.lat,spot.lng);
    const speed=pos.coords.speed==null?0:pos.coords.speed;
    const near=d<=25 && speed<=1.5;
    if(!near){state.arrivalWatch.nearSince=null;state.arrivalWatch.prompted=false;return;}
    if(!state.arrivalWatch.nearSince) state.arrivalWatch.nearSince=Date.now();
    if(!state.arrivalWatch.prompted && Date.now()-state.arrivalWatch.nearSince>=75000){
      state.arrivalWatch.prompted=true;
      if(confirm('Sembra che tu abbia parcheggiato qui. Confermi?')) occupySpot(spot.id,null);
      else state.arrivalWatch.nearSince=Date.now();
    }
  },()=>{}, {enableHighAccuracy:true,maximumAge:5000,timeout:10000});
}

// ---------- CERCO ----------
function initCercoMap(lat,lng){
  if(!state.cerco.map){state.cerco.map=L.map('cerco-map').setView([lat,lng],15);addOsmTileLayer(state.cerco.map);state.cerco.markersLayer=L.layerGroup().addTo(state.cerco.map);state.cerco.userMarker=L.marker([lat,lng],{icon:userDotIcon(),interactive:false}).addTo(state.cerco.map);state.cerco.radiusCircle=L.circle([lat,lng],{radius:state.cerco.radius,weight:1,fillOpacity:.06}).addTo(state.cerco.map);}
  else{state.cerco.map.setView([lat,lng],15);state.cerco.userMarker.setLatLng([lat,lng]);state.cerco.radiusCircle.setLatLng([lat,lng]).setRadius(state.cerco.radius);}
  setTimeout(()=>state.cerco.map.invalidateSize(),0);
}
function buildSpotPopupContent(spot,dist){
  const vs=visualStatus(spot),c=document.createElement('div');c.className='popup-content';const address=document.createElement('strong');address.textContent=cachedAddress(spot.lat,spot.lng);c.appendChild(address);hydrateAddress(spot.lat,spot.lng,label=>address.textContent=label);const d=document.createElement('span');d.className='popup-dist';d.textContent=formatDistance(dist);c.appendChild(d);
  if(vs==='SCHEDULED'){const t=document.createElement('span');t.className='popup-time';t.textContent=`Si libera tra ${minutesRemaining(spot)} min`;c.appendChild(t);}
  if((vs==='SCHEDULED'||vs==='LIBERO')&&spot.released_by!==state.user?.id){const n=document.createElement('button');n.className='btn-go popup-go';n.textContent='NAVIGA';n.addEventListener('click',()=>navigateToSpot(spot));c.appendChild(n);}
  if(vs==='LIBERO'&&spot.released_by!==state.user?.id){const b=document.createElement('button');b.className='btn-go popup-go';b.textContent='VAI';b.addEventListener('click',()=>claimSpot(spot.id,b,true));c.appendChild(b);}
  if(vs==='IN_ARRIVO'&&spot.claimed_by===state.user?.id){const n=document.createElement('button');n.className='btn-go popup-go';n.textContent='NAVIGA';n.addEventListener('click',()=>navigateToSpot(spot));c.appendChild(n);const b=document.createElement('button');b.className='btn-go btn-red popup-go';b.textContent='SONO ARRIVATO';b.addEventListener('click',()=>occupySpot(spot.id,b));c.appendChild(b);}
  return c;
}
function renderCercoMap(){if(!state.cerco.map||!state.cerco.markersLayer||state.cerco.lat==null)return;const {lat,lng,radius,spots}=state.cerco;state.cerco.markersLayer.clearLayers();state.cerco.radiusCircle?.setRadius(radius);spots.map(s=>({...s,_dist:haversineMeters(lat,lng,s.lat,s.lng)})).filter(s=>s._dist<=radius&&s.status!=='OCCUPATO'&&(s.status!=='IN_ARRIVO'||s.claimed_by===state.user?.id)).forEach(spot=>{const vs=visualStatus(spot);let icon=vs==='SCHEDULED'?timedPinIcon(minutesRemaining(spot)):pinIcon(vs==='IN_ARRIVO'?'pin-red':'pin-green');const m=L.marker([spot.lat,spot.lng],{icon}).addTo(state.cerco.markersLayer);m.bindPopup(buildSpotPopupContent(spot,spot._dist));});}
function startCerco(){if(!requireAuth())return;const status=$('cerco-status'),badge=$('cerco-test-badge');status.textContent='Rilevamento posizione GPS…';badge.classList.add('hidden');geolocate((lat,lng)=>{Object.assign(state.cerco,{lat,lng,isTest:false});status.textContent='Posizione rilevata tramite GPS.';initCercoMap(lat,lng);loadNearbySpots();subscribeCerco();},()=>{Object.assign(state.cerco,{lat:TEST_LAT,lng:TEST_LNG,isTest:true});status.textContent='GPS non disponibile.';badge.classList.remove('hidden');initCercoMap(TEST_LAT,TEST_LNG);loadNearbySpots();subscribeCerco();});}
document.querySelectorAll('#radius-chips .chip').forEach(chip=>chip.addEventListener('click',()=>{document.querySelectorAll('#radius-chips .chip').forEach(c=>c.classList.remove('active'));chip.classList.add('active');state.cerco.radius=parseInt(chip.dataset.radius,10);state.cerco.radiusCircle?.setRadius(state.cerco.radius);renderSpotList();checkScheduledNotifications();}));
function haversineMeters(lat1,lng1,lat2,lng2){const R=6371000,toRad=d=>d*Math.PI/180,dLat=toRad(lat2-lat1),dLng=toRad(lng2-lng1);const a=Math.sin(dLat/2)**2+Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLng/2)**2;return 2*R*Math.asin(Math.sqrt(a));}
async function loadNearbySpots(){if(!requireAuth())return;const {data,error}=await state.supabase.from('parking_spots').select('*').neq('status','OCCUPATO').order('created_at',{ascending:false}).limit(300);if(error){showToast('Errore nel caricamento parcheggi: '+error.message);return;}state.cerco.spots=data||[];renderSpotList();checkScheduledNotifications();}
function stopCercoChannel(){if(state.cerco.channel&&state.supabase){state.supabase.removeChannel(state.cerco.channel);state.cerco.channel=null;}}
function subscribeCerco(){if(!state.supabase)return;stopCercoChannel();state.cerco.channel=state.supabase.channel('parking_spots_changes').on('postgres_changes',{event:'*',schema:'public',table:'parking_spots'},payload=>{if(payload.eventType==='DELETE')state.cerco.spots=state.cerco.spots.filter(s=>s.id!==payload.old.id);else{const spot=payload.new,idx=state.cerco.spots.findIndex(s=>s.id===spot.id),previous=idx>=0?state.cerco.spots[idx]:null;if(previous&&previous.status==='LIBERO'&&spot.status==='IN_ARRIVO'&&spot.claimed_by!==state.user?.id)notifySpotTaken(spot);if(idx>=0)state.cerco.spots[idx]=spot;else state.cerco.spots.unshift(spot);if(payload.eventType==='INSERT')notifyForNewSpot(spot);}renderSpotList();checkScheduledNotifications();}).subscribe();}
function renderSpotList(){
  const list=$('spot-list'),{lat,lng,radius,spots}=state.cerco;if(lat==null)return;
  renderCercoMap();
  const rows=spots.map(s=>({...s,_dist:haversineMeters(lat,lng,s.lat,s.lng)}))
    .filter(s=>s._dist<=radius&&s.status!=='OCCUPATO'&&(s.status!=='IN_ARRIVO'||s.claimed_by===state.user?.id))
    .sort((a,b)=>{const av=visualStatus(a),bv=visualStatus(b);if(av==='LIBERO'&&bv!=='LIBERO')return -1;if(bv==='LIBERO'&&av!=='LIBERO')return 1;return a._dist-b._dist;});
  if($('spot-count')) $('spot-count').textContent=String(rows.length);
  if(!rows.length){list.innerHTML='<p class="empty-hint">Nessun parcheggio trovato nel raggio selezionato.</p>';return;}
  list.innerHTML='';
  rows.forEach(spot=>{
    const vs=visualStatus(spot),card=document.createElement('div');card.className='spot-card status-'+vs.toLowerCase();
    const info=document.createElement('div');info.className='spot-info';const addressId=`addr-${spot.id}`;
    info.innerHTML=`<div class="spot-address" id="${addressId}">${cachedAddress(spot.lat,spot.lng)}</div><div class="spot-dist">${formatDistance(spot._dist)}</div><div class="spot-meta">${vs==='SCHEDULED'?'Disponibile tra '+minutesRemaining(spot)+' min':new Date(spot.created_at).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'})}</div><span class="badge badge-${vs.toLowerCase()}">${vs==='SCHEDULED'?'SI LIBERA':vs.replace('_',' ')}</span>`;
    card.appendChild(info);hydrateAddress(spot.lat,spot.lng,label=>{const el=$(addressId);if(el)el.textContent=label;});
    const actions=document.createElement('div');actions.className='spot-actions';
    // NAVIGA is always available for another user's scheduled/free spot, and for the claimant after VAI.
    if((vs==='SCHEDULED'||vs==='LIBERO')&&spot.released_by!==state.user?.id){const n=document.createElement('button');n.className='btn-go';n.textContent='NAVIGA';n.addEventListener('click',()=>navigateToSpot(spot));actions.appendChild(n);}
    if(vs==='LIBERO'&&spot.released_by!==state.user?.id){const b=document.createElement('button');b.className='btn-go';b.textContent='VAI';b.addEventListener('click',()=>claimSpot(spot.id,b,true));actions.appendChild(b);}
    if(vs==='IN_ARRIVO'&&spot.claimed_by===state.user?.id){const n=document.createElement('button');n.className='btn-go';n.textContent='NAVIGA';n.addEventListener('click',()=>navigateToSpot(spot));actions.appendChild(n);const b=document.createElement('button');b.className='btn-go btn-red';b.textContent='SONO ARRIVATO';b.addEventListener('click',()=>occupySpot(spot.id,b));actions.appendChild(b);}
    if(actions.children.length)card.appendChild(actions);list.appendChild(card);
  });
}
function notifyForNewSpot(spot){if(!spotInCurrentRadius(spot)||spot.released_by===state.user?.id)return;const dist=formatDistance(haversineMeters(state.cerco.lat,state.cerco.lng,spot.lat,spot.lng));if(isScheduled(spot)){const m=minutesRemaining(spot);if(m<=10)sendBrowserNotification('Parkest – Si libera tra poco',`Un parcheggio a ${dist} sarà disponibile tra ${m} min.`,spot,`${spot.id}:10`);}else if(spot.status==='LIBERO')sendBrowserNotification('Parkest – Posteggio libero',`Un parcheggio è disponibile a ${dist} da te.`,spot,`${spot.id}:free`);}
function notifySpotTaken(spot){
  if(!spotInCurrentRadius(spot))return;
  const dist=formatDistance(haversineMeters(state.cerco.lat,state.cerco.lng,spot.lat,spot.lng));
  if(navigator.vibrate) navigator.vibrate([180,100,180]);
  sendBrowserNotification('Parkest – Parcheggio non più disponibile',`Il parcheggio a ${dist} è stato preso da un altro utente.`,spot,`${spot.id}:taken`);
}
function checkScheduledNotifications(){if(state.cerco.lat==null)return;state.cerco.spots.forEach(spot=>{if(!spotInCurrentRadius(spot)||spot.released_by===state.user?.id||spot.status!=='LIBERO')return;const m=minutesRemaining(spot),dist=formatDistance(haversineMeters(state.cerco.lat,state.cerco.lng,spot.lat,spot.lng));if(isScheduled(spot)&&m<=10)sendBrowserNotification('Parkest – Si libera tra poco',`Un parcheggio a ${dist} sarà disponibile tra ${m} min.`,spot,`${spot.id}:10`);if(!isScheduled(spot))sendBrowserNotification('Parkest – Posteggio libero',`Un parcheggio è disponibile a ${dist} da te.`,spot,`${spot.id}:free`);});}

// ---------- Home summary ----------
function refreshHomeSummary(){if(!state.supabase||!state.user)return;geolocate(async(lat,lng)=>updateHomeSummaryAt(lat,lng),async()=>updateHomeSummaryAt(TEST_LAT,TEST_LNG));}
async function updateHomeSummaryAt(lat,lng){const {data,error}=await state.supabase.from('parking_spots').select('*').neq('status','OCCUPATO').limit(300);if(error){$('home-summary').textContent='Impossibile aggiornare i parcheggi vicini.';return;}const near=(data||[]).map(s=>({...s,_dist:haversineMeters(lat,lng,s.lat,s.lng)})).filter(s=>s._dist<=HOME_RADIUS);const free=near.filter(s=>visualStatus(s)==='LIBERO').length;const soon=near.filter(s=>visualStatus(s)==='SCHEDULED'&&minutesRemaining(s)<=15).length;$('home-summary').innerHTML=`<b>${near.length} ${near.length===1?'posto':'posti'} entro 500 m</b><br>${free} ${free===1?'libero':'liberi'} ora · ${soon} ${soon===1?'disponibile':'disponibili'} entro 15 min`;}

// Refresh countdowns / visual transitions without reloading.
setInterval(()=>{if($('view-cerco').classList.contains('active')){renderSpotList();checkScheduledNotifications();}},30000);

// ---------- Init ----------
updateNotificationButton();
loadSavedConnection();
